<div class="is-<?php echo flatsome_option('breadcrumb_size'); ?>">
  <?php woocommerce_breadcrumb(); ?>
</div>
