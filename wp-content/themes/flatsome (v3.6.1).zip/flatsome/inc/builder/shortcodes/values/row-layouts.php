<?php

return array(
    'slider' => 'Slider',
    'slider-full' => 'Full Slider',
    'row' => 'Row',
    'masonry' => 'Masonry',
    'grid' => 'Grid',
)

?>