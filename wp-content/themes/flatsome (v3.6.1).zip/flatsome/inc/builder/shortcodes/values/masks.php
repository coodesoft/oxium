<?php
return array(
  '' => 'None',
  'circle' => 'Circle',
  'arrow' => 'Arrow',
  'angled' => 'Angled Left',
  'angled-right' => 'Angled Right',
  'arrow-large' => 'Large - Arrow',
  'angled-large' => 'Large - Angled Left',
  'angled-right-large' => 'Large - Angled Right',
)

?>